[![Version Badge](https://anaconda.org/atztogo/phonopy/badges/version.svg)](https://anaconda.org/atztogo/phonopy)
[![Downloads Badge](https://anaconda.org/atztogo/phonopy/badges/downloads.svg)](https://anaconda.org/atztogo/phonopy)
[![PyPI](https://img.shields.io/pypi/dm/phonopy.svg?maxAge=2592000)](https://pypi.python.org/pypi/phonopy)
[![Build Status](https://travis-ci.org/atztogo/phonopy.svg?branch=master)](https://travis-ci.org/atztogo/phonopy)

phonopy
=======

Phonon code. For the details, see http://atztogo.github.io/phonopy/
